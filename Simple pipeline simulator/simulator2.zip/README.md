环境：
gcc.exe (x86_64-posix-seh-rev0, Built by MinGW-W64 project) 8.1.0
Windows 10
vscode version 1.78

编译方式：
使用gcc编译器直接编译main.cpp文件即可